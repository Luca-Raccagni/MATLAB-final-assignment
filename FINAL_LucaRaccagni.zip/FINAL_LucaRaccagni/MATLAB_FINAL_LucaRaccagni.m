%% FINAL ASSIGNMENT %% 

%% DISCLAIMER OF AI USE %%

% I have used AI only to understand how the reading of audio files works
% and to understand how to manage some functionalities of tables. In the
% code i have commented to the side of every line that in some way is related to AI
% usage. No code from AI has been used whatsoever and for those few
% functions that I found with it, I made sure to understand how they work
% and I have applied them personally to my code. 
%
% Enjoy the program!

%% Initial variables %%

clear all
close all

Screen('Preference', 'SkipSyncTests', 1);
InitializePsychSound(1)
KbName('UnifyKeyNames')

dataFileName = 'user_progress.mat';
winSize = [0 0 1422 800];
winColour = [255 255 255]; 
[win, screenRect] = Screen('OpenWindow', 0, winColour, winSize);
Screen('TextSize', win, 60)
black = [0 0 0];
samplingRate = 48000;
introduction = 'Welcome! \nAre you ready to play? \nPress enter to start!';
id_intro = 'Now write your name\nand hit enter! \n';
id_name = [];
welcome = 'WELCOME, ';
imageRect = [(winSize(3)/2)-140, (winSize(4)/3)-90, (winSize(3)/2)+140, (winSize(4)/3)+190];
imageRect_1 = [(winSize(3)*0.3)-100, (winSize(4)/2)-100, (winSize(3)*0.3)+100, (winSize(4)/2)+100];
imageRect_2 = [(winSize(3)*0.7)-100, (winSize(4)/2)-100, (winSize(3)*0.7)+100, (winSize(4)/2)+100];
rect1_frame = [(winSize(3)*0.3)-150, (winSize(4)/2)-150, (winSize(3)*0.3)+150, (winSize(4)/2)+150];
rect2_frame = [(winSize(3)*0.7)-150, (winSize(4)/2)-150, (winSize(3)*0.7)+150, (winSize(4)/2)+150];
checkRect = [(winSize(3)*0.63)-75, (winSize(4)*0.68)+10, (winSize(3)*0.63)+5, (winSize(4)*0.68)+90];
mstk_phrase = {'NOPE!', 'WHOOPS!', 'WRONG!'};
crrct_phrase = {'CORRECT!', 'PERFECT!', 'SUPER!'};

word_list = {'ANT', 'BANANA', 'BAT', 'BELT', 'CANARY', 'CAPE', 'CAT', 'DRESS', 'DUCK', 'GOAT', 'JACKET', 'LADDER', 'LEMON', 'MOLE', 'PENGUIN', 'RABBIT', 'SHIRT',...
    'SKUNK', 'TIGER', 'ZEBRA'};
im_list = {'ant.jpg', 'banana.jpg', 'bat.jpg', 'belt.jpg', 'canary.jpg', 'cape.jpg', 'cat.jpg', 'dress.jpg', 'duck.jpg', 'goat.jpg', 'jacket.jpg', 'ladder.jpg', 'lemon.jpg', ...
    'mole.jpg', 'penguin.jpg', 'rabbit.jpg', 'shirt.jpg', 'skunk.jpg', 'tiger.jpg', 'zebra.jpg'};
sound_list = {'ant.wav', 'banana.wav', 'bat.wav', 'belt.wav', 'canary.wav', 'cape.wav', 'cat.wav', 'dress.wav', 'duck.wav', 'goat.wav', 'jacket.wav', 'ladder.wav', 'lemon.wav', ...
    'mole.wav', 'penguin.wav', 'rabbit.wav', 'shirt.wav', 'skunk.wav', 'tiger.wav', 'zebra.wav'};
letter_list = {'A.wav', 'B.wav', 'C.wav', 'D.wav', 'E.wav', 'F.wav', 'G.wav', 'H.wav', 'I.wav', 'J.wav', 'K.wav', 'L.wav', 'M.wav', 'N.wav', 'O.wav', 'P.wav', ...
    'Q.wav', 'R.wav', 'S.wav', 'T.wav', 'U.wav', 'V.wav', 'W.wav', 'X.wav', 'Y.wav', 'Z.wav'};
let_im_list = {'AA.jpg', 'BB.jpg', 'CC.jpg', 'DD.jpg', 'EE.jpg', 'FF.jpg', 'GG.jpg', 'HH.jpg', 'II.jpg', 'JJ.jpg', 'KK.jpg', 'LL.jpg', 'MM.jpg', 'NN.jpg', 'OO.jpg', 'PP.jpg', ...
    'QQ.jpg', 'RR.jpg', 'SS.jpg', 'TT.jpg', 'UU.jpg', 'VV.jpg', 'WW.jpg', 'XX.jpg', 'YY.jpg', 'ZZ.jpg', };


tag_ex1 = '- EXERCISE 1';
tag_ex2 = '- EXERCISE 2';
tag_ex3 = '- EXERCISE 3';
tag_mstks = '- PRACTICE MISTAKES';
tag_login = 'LOGOUT';
tag_info = 'INFO';
instr_ex1 = 'In the following exercise, type\nthe name of the images\nthat will pop up!\nPress any key when you''re ready!';
instr_ex2 = 'In this exercise you will\nhear some words.\nListen carefully and try\nto type their name.\nPress any key to start!';
instr_ex3 = 'Now you''ll hear a letter and\nyou have to use the right and\nleft arrow to decide if it''s\nthe letter shown on the left\nor on the right.\nPress any key to begin';

rect_exit = [winSize(3)-75, 0, winSize(3), 40];
rect_ex1 = [50, (winSize(4)*0.3)-65, 450, (winSize(4)*0.3)+25];
rect_ex2 = [50, (winSize(4)*0.5)-65, 450, (winSize(4)*0.5)+25];
rect_ex3 = [50, (winSize(4)*0.7)-65, 450, (winSize(4)*0.7)+25];
rect_mstks = [50, (winSize(4)*0.9)-65, 450, (winSize(4)*0.9)+25];
rect_login = [winSize(3)-200, (winSize(4)*0.3)-45, winSize(3)-20, (winSize(4)*0.3)+25];
rect_frame = [(winSize(3)/2)-411 (winSize(4)/2)-228 (winSize(3)/2)+411 (winSize(4)/2)+228];
ex_rect_frame = [winSize(3)*0.30 (winSize(4)*0.68)-20 winSize(3)*0.70 (winSize(4)*0.68)+120];
im_rect_frame = [(winSize(3)/2)-200, (winSize(4)/3)-150, (winSize(3)/2)+200, (winSize(4)/3)+250];
welcome_rect = [winSize(3)/2-450 88 winSize(3)/2+450 188];

mistakes_ex1 = [];
mistakes_ex2 = [];
mistakes_ex3 = [];
ex1_acc = [];
ex2_acc = [];
image_frame = imread('frame_for_im.jpg');
im_frame = Screen('MakeTexture', win, image_frame);

if exist('user_progress.mat', 'file') % this 'if' statement was proposed entirely by AI (except for table's variables of course), as I wanted to make sure that the table for saving trials could be opened in any case
    load('user_progress.mat', 'tab'); % it simply checks if a file with the table already exists and uploads it if it does, while it creates the table if it doesn't.
else
    tab = table('Size', [0 5], 'VariableTypes', {'datetime','string', 'double', 'double', 'string'}, 'VariableNames', {'Date', 'Exercise', 'Trial n.', 'Mistakes', 'Accuracy'});
end

state = 'login'; 

%% start of the loop %%

while ~strcmp(state, 'exit') % the whole code works based on this loop that checks in which page the user is at any time by comparing the state variable with the strings assigned to the various pages.

    if strcmp(state, 'login')
        frame_im = imread('frame.jpg');
        frame = Screen('MakeTexture', win, frame_im);
        bg_im = imread('cloud_greenblue.jpg');
        login_bg = Screen('MakeTexture', win, bg_im);
        Screen('DrawTexture', win, login_bg, [], winSize)
        Screen('DrawTexture', win, frame, [], rect_frame)
        Screen('TextSize', win, 60)
        DrawFormattedText(win, introduction, 'center', 'center', black)
        Screen('Flip', win)
        while ~strcmp(state, 'home')==1
        [secs, keyCode] = KbStrokeWait(-1);
        key = KbName(keyCode);
            if strcmp('Return', key) == 1
                 Screen('DrawTexture', win, login_bg, [], winSize)
                 Screen('DrawTexture', win, frame, [], rect_frame)
                 DrawFormattedText(win, id_intro, 'center', 'center')
                 Screen('Flip', win)
                 while ~strcmp(state, 'home')==1
                     Screen('DrawTexture', win, login_bg, [], winSize)
                     Screen('DrawTexture', win, frame, [], rect_frame)
                     [secs, keyCode] = KbStrokeWait(-1);
                     keyName = KbName(keyCode);
                     if strcmp('Return', keyName)==1
                         state='home';
                     elseif strcmp('BackSpace', keyName)==1
                         id_name=id_name(1:end-1);
                         id_intro=id_intro(1:end-1);
                         welcome = welcome(1:end-1);
                         DrawFormattedText(win, id_intro, 'center', 'center')
                         Screen('Flip', win)
                         disp('here')
                     elseif length(keyName)==1
                         id_name=[id_name upper(keyName)];
                         id_intro = [id_intro upper(keyName)];
                         welcome = [welcome, upper(keyName)];
                         DrawFormattedText(win, id_intro, 'center', 'center')
                         Screen('Flip', win)
                     end
                 end
            end
         end
    end

    if strcmp(state, 'home')
        bg_im = imread('cloud__lblue.jpg');
        button_im1 = imread('Ex1_button.jpg');
        button_im2 = imread('Ex2_button.jpg');
        button_im3 = imread('Ex3_button.jpg');
        button_im4 = imread('mstks_button.jpg');
        button_im5 = imread('logout_button.jpg');
        button_im6 = imread('x_button.jpg');
        button_ex1 = Screen('MakeTexture', win, button_im1);
        button_ex2 = Screen('MakeTexture', win, button_im2);
        button_ex3 = Screen('MakeTexture', win, button_im3);
        button_mstks = Screen('MakeTexture', win, button_im4);
        button_logout = Screen('MakeTexture', win, button_im5);
        button_exit = Screen('MakeTexture', win, button_im6);
        
        while strcmp(state, 'home')==1
            home_bg = Screen('MakeTexture', win, bg_im);
            Screen('DrawTexture', win, home_bg, [], winSize)
            Screen('DrawTexture', win, button_ex1, [], rect_ex1)
            Screen('DrawTexture', win, button_ex2, [], rect_ex2)
            Screen('DrawTexture', win, button_ex3, [], rect_ex3)
            Screen('DrawTexture', win, button_mstks, [], rect_mstks)
            Screen('DrawTexture', win, button_logout, [], rect_login)
            Screen('DrawTexture', win, button_exit, [], rect_exit)
            Screen('TextSize', win, 60)
            Screen('TextSize', win, 50)
            DrawFormattedText(win, [welcome '!'], 'center', winSize(4)*0.1+30, [230 230 250])
            Screen('TextSize', win, 40)
            Screen('Flip', win)
            [Mx, My, button] = GetMouse(win);
            if button(1) && Mx>rect_exit(1) && Mx<rect_exit(3) && My>rect_exit(2) && My<rect_exit(4)
                state='exit';
            elseif button(1) && Mx>rect_ex1(1) && Mx<rect_ex1(3) && My>rect_ex1(2) && My<rect_ex1(4)
                state = 'exercise 1';
            elseif button(1) && Mx>rect_ex2(1) && Mx<rect_ex2(3) && My>rect_ex2(2) && My<rect_ex2(4)
                state = 'exercise 2';
            elseif button(1) && Mx>rect_ex3(1) && Mx<rect_ex3(3) && My>rect_ex3(2) && My<rect_ex3(4)
                state = 'exercise 3';
            elseif button(1) && Mx>rect_mstks(1) && Mx<rect_mstks(3) && My>rect_mstks(2) && My<rect_mstks(4)
                state = 'mstks';
            elseif button(1) && Mx>rect_login(1) && Mx<rect_login(3) && My>rect_login(2) && My<rect_login(4)
                state = 'login';
            end
            
        end
    end

    if strcmp(state, 'exercise 1')
        Screen('TextSize', win, 45)
        bg_im = imread('cloud_heaven.jpg');
        ex1_bg = Screen('MakeTexture', win, bg_im);
        Screen('DrawTexture', win, ex1_bg, [], winSize)
        Screen('DrawTexture', win, frame, [], rect_frame)
        DrawFormattedText(win, instr_ex1, 'center', 'center', black)
        Screen('Flip', win)
        thisRun = zeros(1, length(word_list));
        r_ind = randperm(length(word_list), length(word_list));
        crrct_mark = imread('correct_mark.jpg');
        wrng_mark = imread('wrong_mark.jpg');
        KbStrokeWait(-1)
        for ii = 1:length(word_list)
            real_ind = r_ind(ii);
            target = word_list{r_ind(ii)};
            im = imread(im_list{r_ind(ii)});
            texture = Screen('MakeTexture', win, im);
            typedString = '';
            typing = true;
            while typing
                Screen('DrawTexture', win, ex1_bg, [], winSize)
                Screen('DrawTexture', win, frame, [], ex_rect_frame)
                Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                Screen('DrawTexture', win, texture, [], imageRect)
                DrawFormattedText(win, ['This is a: ' typedString], 'center', (winSize(4)*0.7)+50, black)
                Screen('Flip', win)

                [secs, keyCode] = KbStrokeWait(-1);
                keyName = KbName(keyCode); 

                if strcmp(keyName, 'Return')==1
                typing = false;

                elseif strcmp(keyName, 'BackSpace')==1
                    typedString = typedString(1:end-1);
                elseif length(keyName) == 1
                    typedString = [typedString upper(keyName)];
                elseif strcmp(keyName, 'ESCAPE')==1
                    thisRun = [];
                    typing = false;
                    state = 'home';
                    break
                end

            end
            if strcmp(state, 'home') == 1
                break
            end
            Screen('DrawTexture', win, ex1_bg, [], winSize)
            Screen('DrawTexture', win, frame, [], ex_rect_frame)
            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
            Screen('DrawTexture', win, texture, [], imageRect)
            if strcmp(target, typedString)==1
                rand_ind = randi(3);
                current_phrase = crrct_phrase{rand_ind};
                DrawFormattedText(win, current_phrase, winSize(3)/2-150, (winSize(4)*0.7)+50, [0 180 0])
                crrct_texture = Screen('MakeTexture', win, crrct_mark);
                Screen('DrawTexture', win, crrct_texture, [], checkRect)
                Screen('Flip', win)
                pause(0.75)
                
            else 
                thisRun(r_ind(ii)) = 1;
                rand_ind = randi(3);
                current_phrase = mstk_phrase{rand_ind};
                DrawFormattedText(win, current_phrase, winSize(3)/2-150, (winSize(4)*0.7)+50, [220 0 0])
                wrng_texture = Screen('MakeTexture', win, wrng_mark);
                Screen('DrawTexture', win, wrng_texture, [], checkRect)
                Screen('Flip', win)
                pause(1)
                wrong_fb = ['The word was: ' upper(target)];
                Screen('DrawTexture', win, ex1_bg, [], winSize)
                Screen('DrawTexture', win, frame, [], ex_rect_frame)
                DrawFormattedText(win, wrong_fb, 'center', (winSize(4)*0.7)+50)
                Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                Screen('DrawTexture', win, texture, [], imageRect)
                Screen('Flip', win)
                pause(1.5)
            end
            
        end
        mistakes_ex1 = [mistakes_ex1; thisRun];  
        crrct_count = 0;
        for ff = 1:length(word_list)
            if ~isempty(thisRun) && thisRun(ff) == 0 % I found the function 'isempty' by searching on google. 
                crrct_count = crrct_count + 1;
            end
        end
        ex1_trial = tab(tab.Exercise=="Exercise 1", :);
        current_ex1_trial = height(ex1_trial)+1; % I have found the 'height' function using AI.
        current_acc = [num2str((crrct_count/length(word_list))*100) '%'];
        n_mist = length(word_list)-crrct_count;
        ex1_acc = [ex1_acc; (crrct_count/length(word_list))*100];
        tableRow = {datetime('now'), 'Exercise 1', current_ex1_trial, n_mist, current_acc}; % datetime was suggested by AI. I thought it was a nice and marginal addition so I included it.
        if ~isempty(thisRun)
            tab = [tab; tableRow];
            save(dataFileName, 'tab') % function 'save' found with AI as well.  
        end
        state='home';
    end 
    
    if strcmp(state, 'exercise 2')
        Screen('TextSize', win, 45)
        bg_im = imread('cloud_orange.jpg');
        ex2_bg = Screen('MakeTexture', win, bg_im);
        Screen('DrawTexture', win, ex2_bg, [], winSize)
        Screen('DrawTexture', win, frame, [], rect_frame)
        DrawFormattedText(win, instr_ex2, 'center', 'center', black)
        Screen('Flip', win)
        thisRun = zeros(1, length(word_list));
        r_ind = randperm(length(word_list), length(word_list));
        crrct_mark = imread('correct_mark.jpg');
        wrng_mark = imread('wrong_mark.jpg');
        pahandle = PsychPortAudio('Open',  [], [], [], samplingRate, 1);
        KbStrokeWait(-1)
        for ll = 1:length(word_list)
            target = word_list{r_ind(ll)};
            im = imread(im_list{r_ind(ll)});
            texture = Screen('MakeTexture', win, im);
            [mySound, freq] = audioread(sound_list{r_ind(ll)}); %used AI to understand how the reading of .wav files works.
            PsychPortAudio('FillBuffer', pahandle, mySound')
            typedString = '';
            typing = true;
            Screen('DrawTexture', win, ex2_bg, [], winSize)
            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
            Screen('Flip', win)
            pause(1)
            PsychPortAudio('Start', pahandle)

            while typing
                Screen('DrawTexture', win, ex2_bg, [], winSize)
                Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                Screen('DrawTexture', win, frame, [], ex_rect_frame)
                DrawFormattedText(win, ['The word is: ' typedString], 'center', winSize(4)*0.7+50, black)
                Screen('Flip', win)

                [secs, keyCode] = KbStrokeWait(-1);
                keyName = KbName(keyCode); 

                if strcmp(keyName, 'Return')==1
                typing = false;

                elseif strcmp(keyName, 'BackSpace')==1
                    typedString = typedString(1:end-1);
                elseif length(keyName) == 1
                    typedString = [typedString upper(keyName)];
                elseif strcmp(keyName, 'ESCAPE')==1
                    thisRun = [];
                    typing = false;
                    state = 'home';
                    break
                else 
                    pause(0)
                end

            end
            if strcmp(state, 'home') == 1
                break
            end

            if strcmp(target, typedString)==1
                rand_ind = randi(3);
                current_phrase = crrct_phrase{rand_ind};
                Screen('DrawTexture', win, ex2_bg, [], winSize)
                Screen('DrawTexture', win, frame, [], ex_rect_frame)
                Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                DrawFormattedText(win, current_phrase, winSize(3)/2-130, winSize(4)*0.7+50, [0 180 0])
                crrct_texture = Screen('MakeTexture', win, crrct_mark);
                Screen('DrawTexture', win, crrct_texture, [], checkRect)
                Screen('DrawTexture', win, texture, [], imageRect)
                Screen('Flip', win)
                pause(0.75)
                
            else 
                thisRun(r_ind(ll)) = 1;
                rand_ind = randi(3);
                current_phrase = mstk_phrase{rand_ind};
                Screen('DrawTexture', win, ex2_bg, [], winSize)
                Screen('DrawTexture', win, frame, [], ex_rect_frame)
                DrawFormattedText(win, current_phrase, winSize(3)/2-130, winSize(4)*0.7+50, [220 0 0])
                wrng_texture = Screen('MakeTexture', win, wrng_mark);
                Screen('DrawTexture', win, wrng_texture, [], checkRect)
                Screen('Flip', win)
                pause(1)
                wrong_fb = ['The word was: ' upper(target)];
                Screen('DrawTexture', win, ex2_bg, [], winSize)
                Screen('DrawTexture', win, frame, [], ex_rect_frame)
                Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                DrawFormattedText(win, wrong_fb, 'center', winSize(4)*0.7+50, black)
                Screen('DrawTexture', win, texture, [], imageRect)
                Screen('Flip', win)
                pause(1.5)
            end
            
        end
        mistakes_ex2 = [mistakes_ex2; thisRun];
        crrct_count = 0;
        for ff = 1:length(word_list)
            if ~isempty(thisRun) && thisRun(ff) == 0
                crrct_count = crrct_count + 1;
            end
        end
        ex2_trial = tab(tab.Exercise=="Exercise 2", :);
        current_ex2_trial = height(ex2_trial)+1;
        current_acc = [num2str((crrct_count/length(word_list))*100) '%'];
        n_mist = length(word_list)-crrct_count;
        ex2_acc = [ex2_acc; (crrct_count/length(word_list))*100];
        tableRow = {datetime('now'), 'Exercise 2', current_ex2_trial, n_mist, current_acc}; 
        if ~isempty(thisRun)
            tab = [tab; tableRow];
            save(dataFileName, 'tab')
        end
        state='home';
    end         

    if strcmp(state, 'exercise 3')
        Screen('TextSize', win, 45)
        bg_im = imread('cloud_violet.jpg');
        ex3_bg = Screen('MakeTexture', win, bg_im);
        Screen('DrawTexture', win, ex3_bg, [], winSize)
        Screen('DrawTexture', win, frame, [], rect_frame)
        DrawFormattedText(win, instr_ex3, 'center', 'center', black)
        Screen('Flip', win)
        pahandle = PsychPortAudio('Open',  [], [], [], samplingRate, 1);
        crrct_mark = imread('correct_mark.jpg');
        wrng_mark = imread('wrong_mark.jpg');
        crrct_count = 0;
        KbStrokeWait(-1)
        for kk = 1:15
            Screen('DrawTexture', win, ex3_bg, [], winSize)
            Screen('Flip', win)
            ind_26 = randperm(26, 26);
            im1 = imread(let_im_list{ind_26(kk)});
            im2 = imread(let_im_list{ind_26(kk+1)});
            texture1 = Screen('MakeTexture', win, im1);
            texture2 = Screen('MakeTexture', win, im2);
            rand_cond = randperm(2,1);
            if rand_cond == 1
                [mySound, freq] = audioread(letter_list{ind_26(kk)});
            elseif rand_cond == 2
                [mySound, freq] = audioread(letter_list{ind_26(kk+1)});
            end
            PsychPortAudio('FillBuffer', pahandle, mySound')
            PsychPortAudio('Start', pahandle)
            first_loop = true;
            while first_loop
                Screen('DrawTexture', win, ex3_bg, [], winSize)
                Screen('DrawTexture', win, im_frame, [], rect1_frame)
                Screen('DrawTexture', win, im_frame, [], rect2_frame)
                Screen('DrawTexture', win, texture1, [], imageRect_1)
                Screen('DrawTexture', win, texture2, [], imageRect_2)
                Screen('Flip', win)
                answer = true;
                while answer
                    [secs, keyCode] = KbStrokeWait(-1);
                    keyName = KbName(keyCode);
                if strcmp(keyName, 'RightArrow') && rand_cond == 1
                    rand_ind = randi(3);
                    current_phrase = mstk_phrase{rand_ind};
                    Screen('DrawTexture', win, ex3_bg, [], winSize)
                    Screen('DrawTexture', win, frame, [], ex_rect_frame)
                    DrawFormattedText(win, current_phrase, winSize(3)/2-130, winSize(4)*0.7+50, [220 0 0])
                    wrng_texture = Screen('MakeTexture', win, wrng_mark);
                    Screen('DrawTexture', win, wrng_texture, [], checkRect)
                    Screen('Flip', win)
                    pause(1)
                    answer = false;
                elseif strcmp(keyName, 'RightArrow') && rand_cond == 2
                    crrct_count = crrct_count+1;
                    rand_ind = randi(3);
                    current_phrase = crrct_phrase{rand_ind};
                    Screen('DrawTexture', win, ex3_bg, [], winSize)
                    Screen('DrawTexture', win, frame, [], ex_rect_frame)
                    DrawFormattedText(win, current_phrase, winSize(3)/2-130, winSize(4)*0.7+50, [0 180 0])
                    crrct_texture = Screen('MakeTexture', win, crrct_mark);
                    Screen('DrawTexture', win, crrct_texture, [], checkRect)
                    Screen('Flip', win)
                    pause(1)
                    answer = false;
                elseif strcmp(keyName, 'LeftArrow') && rand_cond == 1
                    crrct_count = crrct_count+1;
                    rand_ind = randi(3);
                    current_phrase = crrct_phrase{rand_ind};
                    Screen('DrawTexture', win, ex3_bg, [], winSize)
                    Screen('DrawTexture', win, frame, [], ex_rect_frame)
                    DrawFormattedText(win, current_phrase, winSize(3)/2-130, winSize(4)*0.7+50, [0 180 0])
                    crrct_texture = Screen('MakeTexture', win, crrct_mark);
                    Screen('DrawTexture', win, crrct_texture, [], checkRect)
                    Screen('Flip', win)
                    pause(1)
                    answer = false;
                elseif strcmp(keyName, 'LeftArrow') && rand_cond == 2
                    rand_ind = randi(3);
                    current_phrase = mstk_phrase{rand_ind};
                    Screen('DrawTexture', win, ex3_bg, [], winSize)
                    Screen('DrawTexture', win, frame, [], ex_rect_frame)
                    DrawFormattedText(win, current_phrase, winSize(3)/2-130, winSize(4)*0.7+50, [220 0 0])
                    wrng_texture = Screen('MakeTexture', win, wrng_mark);
                    Screen('DrawTexture', win, wrng_texture, [], checkRect)
                    Screen('Flip', win)
                    pause(1)
                    answer = false;
                elseif strcmp(keyName, 'ESCAPE')

                    state = 'home';
                    answer = false;
                    first_loop = false;
                else 
                    pause(0)
                end
                end
                break
            end
            if strcmp(state, 'home') == 1 
                break
            end
        end
        if strcmp(state, 'home') == 0 
            current_acc = [num2str((crrct_count/15)*100) '%'];
            n_mist = 15-crrct_count;
            ex3_trial = tab(tab.Exercise=="Exercise 3", :);
            current_ex3_trial = height(ex3_trial)+1;
            tableRow = {datetime('now'), "Exercise 3", current_ex3_trial, n_mist, current_acc};
            tab = [tab; tableRow];
            save(dataFileName, 'tab')
        else
            pause(0)
        end
        state = 'home';
    end

    if strcmp(state, 'mstks') % here I basically check if there are mistakes saved for exercise 1 and 2. If there are i present the same exercises with only the mistakes.
        button_im1 = imread('purple_ex1_button.jpg');  % however, I don't collect the mistakes in these 'mistake' exercises. So, if one makes mistakes here, they won't be counted.
        button_im2 = imread('purple_ex2_button.jpg');
        button_im3 = imread('purple_goback_button.jpg');
        button_ex1p = Screen('MakeTexture', win, button_im1);
        button_ex2p = Screen('MakeTexture', win, button_im2);
        button_ex3p = Screen('MakeTexture', win, button_im3);
        bg_im = imread('j_cloud_blue.jpg');
        mstks_bg = Screen('MakeTexture', win, bg_im);
        Screen('DrawTexture', win, mstks_bg, [], winSize)

        if ~isempty(mistakes_ex1)
            mstks_ind1 = find(mistakes_ex1);
        end
        if ~isempty(mistakes_ex2)
            mstks_ind2 = find(mistakes_ex2);
        end

        mstk_rect_1 = [winSize(3)-450 (winSize(4)*0.4)-60 winSize(3)-50 (winSize(4)*0.4)+20];
        mstk_rect_2 = [winSize(3)-450 (winSize(4)*0.6)-60 winSize(3)-50 (winSize(4)*0.6)+20];
        mstk_rect_3 = [winSize(3)-300 (winSize(4)*0.8)-60 winSize(3)-50 (winSize(4)*0.8+20)];
        Screen('DrawTexture', win, button_ex1p, [], mstk_rect_1)
        Screen('DrawTexture', win, button_ex2p, [], mstk_rect_2)
        Screen('DrawTexture', win, button_ex3p, [], mstk_rect_3)
        Screen('TextSize', win, 60)
        DrawFormattedText(win, 'PRACTICE YOUR MISTAKES', 'center', winSize(4)*0.2, [200 200 200])
        Screen('Flip', win)
        while true
            [Mx, My, button] = GetMouse(win);
            if button(1) && Mx>mstk_rect_1(1) && Mx<mstk_rect_1(3) && My>mstk_rect_1(2) && My<mstk_rect_1(4)
                if isempty(mistakes_ex1)
                    no_mstks_im = imread('cloud_confusing.jpg');
                    no_mstks = Screen('MakeTexture', win, no_mstks_im);
                    Screen('DrawTexture', win, no_mstks, [], winSize)
                    Screen('DrawTexture', win, frame, [], rect_frame)
                    DrawFormattedText(win, 'No mistakes are registered \nfor this exercise.\nCome back later!\nPress any key to go back.', 'center', winSize(4)/2-80, black)
                    Screen('Flip', win)
                    KbStrokeWait(-1)
                    break
                    % EXERCISE 1
                else
                    Screen('TextSize', win, 45)
                    randInd1 = Shuffle(mstks_ind1);
                    crrct_mark = imread('correct_mark.jpg');
                    wrng_mark = imread('wrong_mark.jpg');
                    bg_im = imread('cloud_lightning.jpg');
                    ex1_mstks_bg = Screen('MakeTexture', win, bg_im);
                    for ii = 1:length(mstks_ind1)
                        target = word_list{randInd1(ii)};
                        im = imread(im_list{randInd1(ii)});
                        texture = Screen('MakeTexture', win, im);
                        typedString = '';
                        typing = true;
                        while typing
                            Screen('DrawTexture', win, ex1_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            Screen('DrawTexture', win, texture, [], imageRect)
                            DrawFormattedText(win, ['This is a: ' typedString], 'center', winSize(4)*0.7+50, black)
                            Screen('Flip', win)

                            [secs, keyCode] = KbStrokeWait(-1);
                            keyName = KbName(keyCode); 

                            if strcmp(keyName, 'Return')==1
                            typing = false;

                            elseif strcmp(keyName, 'BackSpace')==1
                                typedString = typedString(1:end-1);
                            elseif length(keyName) == 1
                                typedString = [typedString upper(keyName)];
                            elseif strcmp(keyName, 'ESCAPE')==1
                                typing = false;
                                state = 'home';
                                break
                            end

                        end
                        if strcmp(state, 'home') == 1
                            break
                        end
                        Screen('DrawTexture', win, texture, [], imageRect)

                        if strcmp(target, typedString)==1
                            rand_ind = randi(3);
                            current_phrase = crrct_phrase{rand_ind};
                            Screen('DrawTexture', win, ex1_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, current_phrase, 'center', winSize(4)*0.7+50, [0 180 0])
                            crrct_texture = Screen('MakeTexture', win, crrct_mark);
                            Screen('DrawTexture', win, crrct_texture, [], checkRect)
                            Screen('Flip', win)
                            pause(0.75)
                
                        else 
                            thisRun(randInd1(ii)) = 1;
                            rand_ind = randi(3);
                            current_phrase = mstk_phrase{rand_ind};
                            Screen('DrawTexture', win, ex1_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, current_phrase, 'center', winSize(4)*0.7+50, [220 0 0])
                            wrng_texture = Screen('MakeTexture', win, wrng_mark);
                            Screen('DrawTexture', win, wrng_texture, [], checkRect)
                            Screen('Flip', win)
                            pause(1)
                            wrong_fb = ['The word was: ' upper(target)];
                            Screen('DrawTexture', win, ex1_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, wrong_fb, 'center', winSize(4)*0.7)
                            Screen('DrawTexture', win, texture, [], imageRect)
                            Screen('Flip', win)
                            pause(1.5)
                        end
            
                    end
                    mistakes_ex1 = [];
                    break
                end


            elseif button(1) && Mx>mstk_rect_2(1) && Mx<mstk_rect_2(3) && My>mstk_rect_2(2) && My<mstk_rect_2(4)
                if isempty(mistakes_ex2)
                    no_mstks_im = imread('cloud_confusing.jpg');
                    no_mstks = Screen('MakeTexture', win, no_mstks_im);
                    Screen('DrawTexture', win, no_mstks, [], winSize)
                    Screen('DrawTexture', win, frame, [], rect_frame)
                    DrawFormattedText(win, 'No mistakes are registered \nfor this exercise.\nCome back later!\nPress any key to go back.', 'center', winSize(4)/2-80, black)
                    Screen('Flip', win)
                    KbStrokeWait(-1)
                    break
                    % EXERCISE 2
                else
                    Screen('TextSize', win, 45)
                    bg_im = imread('cloud_black_dots.jpg');
                    ex2_mstks_bg = Screen('MakeTexture', win, bg_im);
                    randInd2 = Shuffle(mstks_ind2);
                    crrct_mark = imread('correct_mark.jpg');
                    wrng_mark = imread('wrong_mark.jpg');
                    pahandle = PsychPortAudio('Open',  [], [], [], samplingRate, 1);
                    for l = 1:length(mstks_ind2)
                        target = word_list{randInd2(l)};  
                        im = imread(im_list{randInd2(l)});
                        Screen('DrawTexture', win, ex2_mstks_bg, [], winSize)
                        Screen('DrawTexture', win, frame, [], ex_rect_frame)
                        Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                        texture = Screen('MakeTexture', win, im);
                        [mySound, freq] = audioread(sound_list{randInd2(l)});
                        PsychPortAudio('FillBuffer', pahandle, mySound')
                        typedString = '';
                        typing = true;
                        Screen('Flip', win)
                        pause(1)
                        PsychPortAudio('Start', pahandle)

                        while typing
                            Screen('DrawTexture', win, ex2_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, ['The word is: ' typedString], 'center', winSize(4)*0.7+50, black)
                            Screen('Flip', win)

                            [secs, keyCode] = KbStrokeWait(-1);
                            keyName = KbName(keyCode); 

                            if strcmp(keyName, 'Return')==1
                            typing = false;

                            elseif strcmp(keyName, 'BackSpace')==1
                                typedString = typedString(1:end-1);
                            elseif length(keyName) == 1
                                typedString = [typedString upper(keyName)];
                            elseif strcmp(keyName, 'ESCAPE')==1
                                typing = false;
                                state = 'home'; 
                                break
                            else 
                                pause(0)
                            end

                        end
                        if strcmp(state, 'home') == 1 
                            break
                        end

                        if strcmp(target, typedString)==1
                            rand_ind = randi(3);
                            current_phrase = crrct_phrase{rand_ind};
                            Screen('DrawTexture', win, ex2_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, current_phrase, 'center', winSize(4)*0.7+50, [0 180 0])
                            crrct_texture = Screen('MakeTexture', win, crrct_mark);
                            Screen('DrawTexture', win, crrct_texture, [], checkRect)
                            Screen('DrawTexture', win, texture, [], imageRect)
                            Screen('Flip', win)
                            pause(0.75)
                
                        else 
                            rand_ind = randi(3);
                            current_phrase = mstk_phrase{rand_ind};
                            Screen('DrawTexture', win, ex2_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, current_phrase, 'center', winSize(4)*0.7+50, [220 0 0])
                            wrng_texture = Screen('MakeTexture', win, wrng_mark);
                            Screen('DrawTexture', win, wrng_texture, [], checkRect)
                            Screen('Flip', win)
                            pause(1)
                            wrong_fb = ['The word was: ' upper(target)];
                            Screen('DrawTexture', win, ex2_mstks_bg, [], winSize)
                            Screen('DrawTexture', win, frame, [], ex_rect_frame)
                            Screen('DrawTexture', win, im_frame, [], im_rect_frame)
                            DrawFormattedText(win, wrong_fb, 'center', winSize(4)*0.7+50, black)
                            Screen('DrawTexture', win, texture, [], imageRect)
                            Screen('Flip', win)
                            pause(1.5)
                        end
            
                    end
                    mistakes_ex2 = [];
                    break

                end
            
            elseif button(1) && Mx>mstk_rect_3(1) && Mx<mstk_rect_3(3) && My>mstk_rect_3(2) && My<mstk_rect_3(4)
                state = 'home';
                break
            end
        end
    end
end
sca